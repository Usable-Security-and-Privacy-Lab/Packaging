#! /bin/bash
systemctl start firewalld
