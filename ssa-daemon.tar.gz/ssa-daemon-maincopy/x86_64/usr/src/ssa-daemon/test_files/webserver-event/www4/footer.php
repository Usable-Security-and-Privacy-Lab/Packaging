<html>
<style>

.footer-bot {
    position: fixed;
    bottom: 0;
    width: 100%;
}

</style>
</html>

<br><br><br><br>
<footer class="container-fluid text-center footer-bot">
  <p>PayMore is a fictional website run by the Internet Research Laboratory at Brigham Young University.</p>
</footer>
</body>
</html>

